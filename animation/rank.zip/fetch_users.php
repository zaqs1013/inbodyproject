<?php

// 데이터베이스 연결
$conn = mysqli_connect('localhost', 'root', '', 'fito');

// 변수 설정
$rank = 3; // 원하는 rank 값 설정

// JSON 데이터 반환
echo json_encode(['rank' => $rank]);

// 데이터베이스 연결 닫기
$conn->close();
?>
